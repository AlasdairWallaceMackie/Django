from django.shortcuts import redirect, render, HttpResponse

def home(request):
    return render(request, 'index.html')

def index(request):
    return HttpResponse("placeholder to later display a list of all blogs")

def new(request):
    return HttpResponse("placeholder to display a new form to create a <span style = 'color: red'>new</span> blog")

def create(request):
    return redirect('/')

def show(request, number):
    return HttpResponse(f"<h1>Placeholder</h1> to display blog number: {number}")

def edit(request, number):
    return HttpResponse(f"<h1>Placeholder</h1> to EDIT blog number: {number}")

def destroy(request, number):
    return redirect('/')

# def index(request):
#     return render(request,'index.html')


