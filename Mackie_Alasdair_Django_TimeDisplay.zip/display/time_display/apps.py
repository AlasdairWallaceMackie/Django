from django.apps import AppConfig


class TimeDislpayConfig(AppConfig):
    name = 'time_dislpay'
