from django.shortcuts import render
from time import gmtime, localtime, strftime

def index(request):
    context= {
        'time': strftime( "%Z %a %B %d %Y %I:%M:%S %p", localtime() )
    }
    return render(request, 'index.html', context)
